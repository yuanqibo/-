# ECP SDK Vue Auth Module

`@acg/ecp-auth-vue` 是 ECP SDK 的 Auth Module Vue 组件聚合包，统一提供：

- 登录组件：`@acg/ecp-auth-vue/login/vue`
- 无权限页组件：`@acg/ecp-auth-vue/no-permission/vue`
- 权限配置组件：`@acg/ecp-auth-vue/permission-config/vue`
- Workspace 组件：`@acg/ecp-auth-vue/workspace/vue`
- 账号展示组件：`@acg/ecp-auth-vue/account/vue`
- Header 登录用户组件：`@acg/ecp-auth-vue/header-user/vue`
- 路由调试组件：`@acg/ecp-auth-vue/debug/vue`
- 可插拔 Picker Input：`AuthzPickerInput`
- 通用 Drawer 表单壳层：`AuthzEntityDrawerForm`
- Section 页面布局容器：`AuthzSectionPageLayout`
- 无副作用 runtime 入口：`@acg/ecp-auth-vue/facade`

该包依赖 `@acg/ecp-auth`（认证核心能力），用于将 Vue 视图层与 runtime 解耦。
建议在应用入口安装 `@acg/ecp-ui` 插件，统一注入 `EcpInput/EcpSelect/EcpButton/EcpCheckbox`，确保登录与无权限页控件风格一致。
`@acg/ecp-ui` 会自动安装 SDK 需要的 Element Plus 子模块并注入基础样式，无需业务工程额外维护 Element Plus 根插件的接入细节。

## Workspace 表面约定

Workspace 现在明确区分两类表面：

- ECP 内部应用管理页 `.../ecp/applications/:appCode/roles-members`
  继续使用“角色与成员”语义和 managed `app-role-*` 管理接口；如果是合作伙伴应用，可以切换公司后管理对应公司的成员授权。
- SDK 暴露的嵌入式 workspace
  包括 `@acg/ecp-auth-vue/workspace/vue`、`@acg/ecp-auth-vue/permission-workspace/vue` 和自定义元素 `authz-workspace-body`，统一使用“账号管理”形态做授权管理。

嵌入式 workspace 的规则：

- 普通应用：目录展示与授权主体选择走 `selectable-accounts` / `selectable-departments`，授权写操作继续走应用标准 `app-role-*` 接口，不展示公司切换和账号治理动作。
- 合作伙伴应用：仍然使用账号管理形态，但公司固定为当前登录会话所属公司，不提供跨公司切换。
- 合作伙伴应用只有在当前账号具备 `X5CVCP` 或 `authz:account_set:update` 时，才会在嵌入式 workspace 中打开当前公司范围内的账号目录治理能力；否则保留授权能力，但隐藏新增账号、新增部门、编辑/删除组织节点、重置密码等治理动作。

这套分流只发生在 SDK / workspace 内部编排层，对外公开的 props、events、路由挂载方式保持不变，接入工程不需要改现有调用方式。

## Workspace Public Entrypoints

第三方 Vue3 工程应把 workspace 公开入口理解成下面 3 类表面：

- `auth.defaultSetup.workspace.mountPath` + `quickstart.layoutRouteName` / `workspace.parentRouteName`
  推荐默认方案。让 SDK 直接注册内置 workspace 路由，并把它挂到业务 layout 下。
- `@acg/ecp-auth-vue/workspace/vue`
  route-level host surface。它最终会挂载 `authz-workspace-body`，应作为整个路由内容区使用。
- `@acg/ecp-auth-vue/permission-workspace/vue`
  显式 page-shell surface。适合手工注册 route，但同样应独占整个页面内容区。
- `<authz-workspace-body>`
  Web Component surface。适合非 Vue 或直接 DOM 挂载场景，也应独占整个挂载区域。

严格限制：

- 不要把 `@acg/ecp-auth-vue/workspace/vue`、`@acg/ecp-auth-vue/permission-workspace/vue` 或 `<authz-workspace-body>` 再嵌入本地 `EcpContainer`、`EcpCard`、标题卡片或其他 page shell 中。
- 否则会出现双层 page shell、重复滚动容器、点击遮挡和样式边界错乱。
- 当前 public SDK 还没有把 shell-less workspace core 作为稳定公开入口；如果业务真的需要本地 wrapper，请先补 SDK 公共 core export，而不是把 page shell 再包一层。

## 目标态接入约定

业务应用推荐采用 `authz bundle` 作为本地唯一接入输入：

```text
authz/
  permissions.yaml
  features.yaml
  menus.yaml
  roles.yaml
  workspace.yaml
```

推荐职责：

- `createEcpSdk(...)` / `auth.defaultSetup` / `ecp.setup(...)`：`appCode`、登录配置、runtime 配置
- `permissions.yaml`：顶层 `resources`（资源与权限点）
- `features.yaml`：顶层 `features`（功能树）
- `menus.yaml`：顶层 `menus`（菜单；`id` 可省略并由平台派生）
- `roles.yaml`：顶层 `roles`（角色定义）
- `workspace.yaml`：workspace 挂载配置

兼容说明：

- `0.3.x` 起不再读取本地 `authz/app.yaml` 或 `authz/app.json`。
- 推荐把 app 级配置全部收敛到 TS SDK 入口（`createEcpSdk({ appCode, baseUrl, ... })`）。

本包负责承载这些配置在业务工程中的运行时接入，不建议业务工程自行再发明第二套接入格式。

## v1 样式隔离默认值

`workspace` 默认启用 `styleScopeMode: 'strict'`。严格模式会把 workspace 样式限制在 `.authz-workspace-host` 容器内，避免覆盖业务菜单、布局和 Element Plus 全局主题。

- `strict`（默认）：样式限定在 workspace 容器内，推荐生产使用。
- `legacy`：保留历史全局样式行为，仅用于迁移过渡。

可在 `workspace.yaml` 或 runtime 配置里设置：

```yaml
workspace:
  mountPath: /workspace
  noPermissionPath: /no-permission
  styleScopeMode: strict
```

```ts
await ecp.setup({
  router,
  auth: {
    workspace: {
      styleScopeMode: 'strict'
    }
  }
})
```

## Quick Start（bundle 驱动）

```bash
npm install @acg/ecp-sdk @acg/ecp-auth-vue
```

```ts
import { createBundleFromGlob } from '@acg/ecp-auth-vue'
import { createEcpSdk } from '@acg/ecp-sdk'

const authzFiles = {
  ...import.meta.glob('./authz/*.yaml', { eager: true, import: 'default', query: '?raw' }),
  ...import.meta.glob('/src/views/**/*.vue'),
}

const bundle = createBundleFromGlob(authzFiles)

const ecp = createEcpSdk({
  appCode: 'SALES01',
  baseUrl: '/api/ecp/v1',
  modules: { auth: true },
  auth: {
    bundle
  }
})
```

`createBundleFromGlob(...)` 在 `0.3.x` 会忽略 `authz/app.yaml|json`，如需 quickstart 产物请显式传入 `options.appCode`。

`bundle` 是运行时唯一推荐输入；当菜单项同时提供 `pageKey + file` 时，`createBundleFromGlob(...)` 会把本地 Vue 文件以隐藏元数据挂到 bundle 上，`createEcpSdk(...)` 会自动装配 `pageRegistry`。`file` 只用于当前工程自动 import，不替代 `pageKey` 作为平台稳定标识。

如果你更喜欢 quickstart 帮你提取 `managedPageKeys`，也可以继续使用 `createBundleQuickstartFromGlob(...)`，但请显式传入 `options.appCode`，不要再依赖本地 `app.yaml`：

```ts
const authzArtifacts = createBundleQuickstartFromGlob(authzFiles, {
  appCode: 'SALES01'
})
```

## 内置路由

`createEcpSdk(...).setup({ auth: ... })` 会在初始化 runtime 时自动注册内置页面路由：

- 登录页：`/login`
- 无权限页：`/no-permission`
- Workspace：`/workspace`
- 内置 `/workspace` 默认附带权限要求：`permissionCodes=['authz:app_role:view']`

默认只启登录态。推荐通过 `createEcpSdk(...).setup({ auth: ... })` 显式开启能力块：

```ts
const ecp = createEcpSdk({
  appCode: 'SFI32J',
  modules: { auth: true }
})

await ecp.setup({
  router,
  locale: 'zh-CN'
})
```

- 最小登录接入只需要 `appCode + modules.auth + router`
- 未显式传入 `baseUrl` 时默认走同域 `/api/v1`
- `permission`：显式开启权限守卫
- `menu`：显式开启托管菜单加载与路由挂载
- `workspace`：显式开启 workspace 路由

```ts
import { createApp } from 'vue'
import { createEcpUiPlugin } from '@acg/ecp-ui'
import App from './App.vue'

createApp(App)
  .use(createEcpUiPlugin())
  .mount('#app')
```

## 租户菜单配置与 Router 绑定

菜单配置建议在控制面按“应用 + 业务租户”统一维护，菜单项只存业务字段：

- `path`（路由路径）
- `pageKey`（页面标识）
- `permissionCodes / featureCodes / permissionMode`（访问控制）

正式模型仍然只认 `pageKey`。如果业务工程想减少手写 `pageRegistry`，可以在本地 bundle 里额外提供 `file`，并在 `authz/bundle.ts` 里直接加载 YAML 和 Vue 页面：

```ts
import { createBundleFromGlob } from '@acg/ecp-auth-vue'
import { createEcpSdk } from '@acg/ecp-sdk'

const authzFiles = {
  ...import.meta.glob('./authz/*.yaml', { eager: true, import: 'default', query: '?raw' }),
  ...import.meta.glob('/src/views/**/*.vue'),
}

const bundle = createBundleFromGlob(authzFiles)

const ecp = createEcpSdk({
  appCode: 'SALES01',
  modules: { auth: true },
  auth: {
    bundle
  }
})

await ecp.setup({
  router,
  auth: {
    login: {
      loginPath: '/login'
    },
    permission: {
      noPermissionPath: '/no-permission'
    },
    menu: { router }
  }
})
```

如果应用有统一前缀（例如 `/ecp`），建议在保存菜单时直接使用最终可访问路径，或在业务侧封装统一 path 归一化逻辑后再调用 `configureRouter`。
如果自动装配不够用，仍然可以显式传入 `auth.pageFiles`、`pageRegistry` 或 `componentResolver(pageKey, item)` 覆盖默认行为。

### Menu Access Projection

`useAuthzMenu()` 现在支持显式指定菜单来源和未授权展示策略：

```ts
const { items } = useAuthzMenu({
  source: 'auto',
  unauthorized: 'disable',
})
```

- `source: 'accessible'`
  - 直接使用 `getAccessibleNavTree()`，只保留可访问节点；这是默认行为。
- `source: 'raw'`
  - 使用 `getNavTree()`，再由 SDK 在前端按当前 session 权限做投影。
- `source: 'auto'`
  - 优先使用 `getNavTree()`；当原始菜单树不可用时，自动回退到 `getAccessibleNavTree()`。
- `unauthorized: 'hide'`
  - 隐藏未授权叶子节点；这是默认行为。
- `unauthorized: 'disable'`
  - 保留未授权叶子节点，并在 `AuthzMenuTree` 中自动以禁用态渲染。

如果业务侧需要自定义分组或非标准菜单布局，也可以直接复用 `projectMenuTreeByAccess(...)`，而不必重复实现权限裁剪逻辑。

针对“默认禁用 + 少量页面隐藏”的场景，推荐使用策略对象而不是在业务代码里手写分支：

```ts
import { createMenuUnauthorizedPolicy, projectMenuTree } from '@acg/ecp-auth-vue'

const policy = createMenuUnauthorizedPolicy({
  defaultMode: 'disable',
  byPageKey: {
    SYSTEM_SETUP: 'hide'
  },
  byPath: {
    '/admin/audit': 'hide'
  }
})

const projected = projectMenuTree(rawMenuTree, permissionSnapshot, { policy })
```

在导入控制面前，建议先做本地 bundle 结构校验：

```ts
import { createBundleFromGlob, validateAuthzBundle } from '@acg/ecp-auth-vue'

const bundle = createBundleFromGlob(authzFiles)
const report = validateAuthzBundle(bundle)
if (!report.ok) {
  console.error(report.errors)
}
```

## Doctor

```ts
const report = await ecpAuth.doctor.run()
console.log(report.ok, report.checks)
```

`doctor.run()` 只做本地 bundle / `pageKey` / workspace 配置检查，不再依赖控制面的远端诊断接口。

`0.3.x` 清理窗口如果希望把 `bundle.app.appCode` 与运行时 `appCode` 不一致直接视为失败，可开启严格模式：

```ts
const report = await ecpAuth.doctor.run({
  bundleAppCodeMismatchLevel: 'fail'
})
```

## Build

```bash
cd ecp-sdk-frontend/packages/ecp-auth-vue
npm install
npm run build
```

`workspace` 预构建资产由本包管理，默认查找顺序：

1. `ECP_WORKSPACE_ASSETS_DIR`
2. `AUTHZ_WORKSPACE_ASSETS_DIR`（兼容变量）
3. `workspace-assets/`
4. `ecp-frontend/dist-embed`（monorepo 兼容回退）

## 迁移说明（破坏性升级）

- `@acg/ecp-sdk` 通过 `@acg/ecp-auth-vue/facade` 加载 AUTH 运行时，不再依赖根入口聚合导出。
- 历史依赖 workspace 全局样式覆盖的项目，需要显式设置 `workspace.styleScopeMode: legacy` 才能保持旧行为。
- 推荐宿主应用统一安装 `createEcpUiPlugin()`（或等价 token 注入）再接入 AUTH 组件。
