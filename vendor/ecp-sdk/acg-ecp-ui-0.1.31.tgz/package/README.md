# ECP UI

`@acg/ecp-ui` 提供 ECP 统一基础组件与样式 token，供业务应用和 SDK 组件（如 `@acg/ecp-auth-vue`）复用。
组件已迁移并收口 `ecp-frontend/src/components/base` 的基础 Vue 组件，确保主工程与 SDK 使用同一套组件实现。

## Included Components

- `EcpInput`
- `EcpSelect`
- `EcpButton`
- `EcpCheckbox`
- `EcpCard`
- `EcpContainer`
- `EcpContentHeader`
- `EcpDetailPanel`
- `EcpDrawerHeader`
- `EcpEmptyState`
- `EcpEntityDrawer`
- `EcpEntityDrawerForm`
- `EcpEntitySelector`
- `EcpEntityTreePanel`
- `EcpGuidePanel`
- `EcpInfoRow`
- `EcpPageSkeleton`
- `EcpPickerInput`
- `EcpPermissionDenied`
- `EcpSectionPageLayout`
- `EcpSplitLayout`
- `EcpSwitch`
- `EcpTable`
- `EcpTabs`
- `EcpToolbar`
- `EcpTree`
- `EcpWizardFrame`

兼容导出（别名）：

- `AuthzInput`
- `AuthzSelect`
- `AuthzButton`
- `AuthzCheckbox`

## Usage

```ts
import { createApp } from 'vue'
import { createEcpUiPlugin } from '@acg/ecp-ui'
import App from './App.vue'

createApp(App)
  .use(createEcpUiPlugin())
  .mount('#app')
```

注意：`createEcpUiPlugin()` 会自动引入 `element-plus/dist/index.css`，并按需安装 SDK 运行时自己需要的 Element Plus 子模块。
如果业务应用自身还会直接渲染更多 `el-*` 组件，请在应用入口自行安装 `ElementPlus`，不要依赖 `@acg/ecp-ui` 为业务页面兜底注册全部组件。

也可以按需单独引入组件并注册：

```ts
import { EcpInput, EcpSelect, EcpButton, EcpCheckbox } from '@acg/ecp-ui'
```
