# Authz Frontend SDK

`ecp-sdk-frontend` 提供应用侧接入 Authz 的前端 SDK 骨架，覆盖 3 类核心能力：

1. 登录态管理与自动跳转登录页
2. 当前登录用户上下文读取（个人/组织/租户/公司）
3. 权限与角色快速判断（单个、多个、任一、全部）

UI 视图层（登录、无权限、账号、workspace 等）由 `@acg/ecp-auth-vue` 提供。

## Quick Start

```ts
import { createAuthzBrowserRuntime, handleUnauthorizedError } from '@acg/ecp-auth'

const authz = createAuthzBrowserRuntime({
  defaultAppCode: 'SALES',
  baseUrl: 'https://authz.example.com/api/v1',
  locale: 'zh-CN',
  // 未登录跳转地址规则，可按项目自定义
  resolveLoginPath: (appCode) => `/login/${appCode.toLowerCase()}`
})

// 初始化 + 预加载会话
await authz.bootstrap()

// 获取当前用户信息（优先缓存）
const user = authz.getSessionContext()?.user

// 按需刷新服务端上下文
await authz.loadSessionContext(true)

// 权限判断
const canViewOrder = authz.hasPermission('sales:order:view')
const canManageOrder = authz.hasAllPermissions([
  'sales:order:view',
  'sales:order:update'
])

// Casbin 风格：对象 + 动作（本地判定，条件策略自动回退服务端）
const canViewApplication = await authz.can('authz:application', 'view')
const canCreateApplication = await authz.can('authz:application', 'create', {
  tenantId: 'default'
})

// 加载应用租户菜单（供前端渲染菜单或二次路由装配）
const menuConfig = await authz.loadAppMenuConfig('TENANT_A')
// menuConfig.items[*].pageKey 由业务前端自行映射到具体页面组件

// 登录完成后写入会话（如在 callback 页）
authz.applyLoginSession({
  appCode: 'SALES',
  sessionToken: 'token-from-backend'
})

// axios/fetch 抛错后，统一处理 401 跳转（会忽略 /public/login/**）
try {
  // ...
} catch (error) {
  handleUnauthorizedError(error, {
    isPublicLoginApi: (url) => authz.isPublicLoginApi(url),
    onUnauthorized: () => authz.handleUnauthorized()
  })
}

// Vue Router 可直接安装守卫，避免每个项目重复写 beforeEach
authz.installRouterGuard(router, {
  isPublicRoute: (to) => Boolean(to.meta?.public),
  resolveReturnTo: (to) => to.fullPath
})

```

## Session Invalid Event Hooks

为了避免每个应用重复写会话失效分支，runtime 支持统一回调：

```ts
const authz = createAuthzBrowserRuntime({
  defaultAppCode: 'SALES',
  baseUrl: '/api/v1',
  onSessionInvalid: (event) => {
    console.log(event.reason, event.messageKey)
  },
  onAuthEvent: (event) => {
    console.log(event.type, event.at)
  }
})
```

标准 `reason` 示例：

- `ACCOUNT_DISABLED`
- `SESSION_REPLACED`
- `TOKEN_EXPIRED`
- `TOKEN_INVALID`
- `UNAUTHORIZED`
- `APP_NOT_FOUND`
- `UNKNOWN`

## Runtime AppCode & Snapshot Fallback

当应用需要统一 `appCode` 解析优先级时，推荐使用 SDK 标准入口（`query > storage > host-hint > fallback`）：

```ts
import { resolveRuntimeAppCode } from '@acg/ecp-auth'

const appCode = resolveRuntimeAppCode({
  search: window.location.search,
  appCodeFromStorage: localStorage.getItem('authzAppCode') || '',
  host: window.location.hostname,
  fallbackAppCode: 'ECP'
})
```

当权限快照接口存在短暂波动时，推荐使用带降级兜底的预热入口：

```ts
import { createAuthzSessionSelectors, primePermissionSnapshotWithFallback } from '@acg/ecp-auth'

await primePermissionSnapshotWithFallback(ecpAuth, publicClient, {
  fallbackAppCode: 'ECP',
  selectors: createAuthzSessionSelectors()
})
```

## Login Modes

SDK 同时支持两种登录接入模式：

1. `redirect`：未登录直接跳转到统一登录域名（如 `account.example.com/login`）
2. `embedded`：业务应用站内挂载 `@acg/ecp-auth-vue/login/vue` 登录组件

推荐通过 `createAuthzLoginPathResolver` 统一配置：

```ts
import { createAuthzBrowserRuntime, createAuthzLoginPathResolver } from '@acg/ecp-auth'

const loginMode = (import.meta.env.VITE_ECP_LOGIN_MODE || 'embedded') as 'embedded' | 'redirect'

const resolveLoginPath = createAuthzLoginPathResolver({
  mode: loginMode,
  embeddedLoginPath: '/login',
  redirectLoginUrl: import.meta.env.VITE_ECP_LOGIN_URL || 'http://localhost:5173/login',
  callbackUrl: () => `${window.location.origin}/login/callback/feishu`
})

const authz = createAuthzBrowserRuntime({
  defaultAppCode: 'SALES',
  baseUrl: '/api/v1',
  resolveLoginPath
})
```

登录回调结果建议统一走 SDK 状态机工具：

```ts
import { resolveAuthzPublicLoginFlow } from '@acg/ecp-auth'

const flow = resolveAuthzPublicLoginFlow(result)
if (flow.next === 'APPLY_SESSION') {
  // 写入 session
}
```

## 显式能力开启

SDK 不再使用 `profile` 档位。默认只提供登录态与基础路由能力，权限能力需要显式开启：

你可以直接使用内置一体化启动：

```ts
import { setupAuthzRuntime } from '@acg/ecp-auth'

await setupAuthzRuntime({
  defaultAppCode: 'SALES',
  baseUrl: '/api/v1',
  locale: 'zh-CN',
  router,
  routeGuard: {
    isPublicRoute: (to) => Boolean(to.meta?.public)
  },
  permissionRouteGuard: true
})
```

如果项目希望进一步减少模板代码，可以使用“约定大于配置”入口：

```ts
import { setupAuthzRuntimeWithConventions, requestAuthzApiJson } from '@acg/ecp-auth'

await setupAuthzRuntimeWithConventions({ router })
// 默认约定：
// - appCode: import.meta.env.VITE_ECP_APP_CODE || 'ECP'
// - baseUrl: import.meta.env.VITE_ECP_API_BASE_URL || '/api/ecp/v1'
// - loginPath: '/login'
// - noPermissionPath: '/no-permission'
// - 默认不启权限守卫；传 permissionRouteGuard: true 或对象时才开启

const session = await requestAuthzApiJson('/public/session')
```

如果只需要“登录状态 + 未登录跳转登录页”，可以使用极简入口（只传 `appCode`）：

```ts
import { setupAuthzLoginRuntime } from '@acg/ecp-auth'

await setupAuthzLoginRuntime({
  router,
  appCode: 'SFI32J'
})
```

如果你希望以 ECP 约定直接接入（并可在一个函数里放高阶配置），可使用：

```ts
import { setupEcpSdk } from '@acg/ecp-auth'

await setupEcpSdk({
  router,
  appCode: 'SFI32J'
})
// 默认只启登录态与登录跳转；需要权限守卫时显式传 permissionRouteGuard
```

如果你的项目希望完全不写本地 `authz.ts` 包装层，也可以使用 SDK 内置的单例接口：

```ts
import {
  configureAuthzBrowserRuntime,
  installAuthzRouteGuard,
  installAuthzPermissionRouteGuard,
  bootstrapAuthzRuntime,
  canAuthzAccess,
  getAuthzLoginUrl,
  handleAuthzUnauthorized,
  handleAuthzUnauthorizedError
} from '@acg/ecp-auth'

configureAuthzBrowserRuntime({
  defaultAppCode: 'SALES',
  baseUrl: '/api/v1',
  resolveLoginPath: (appCode) => `/login/${appCode.toLowerCase()}`
})

installAuthzRouteGuard(router)
installAuthzPermissionRouteGuard(router)
await bootstrapAuthzRuntime('zh-CN')

// 401 时可直接交给 SDK 统一处理（自动跳过 /public/login/**）
handleAuthzUnauthorizedError(error)

// 按需跳登录
const loginUrl = getAuthzLoginUrl('SALES', '/orders')

// Casbin 风格权限判断
const allowed = await canAuthzAccess('authz:application', 'view')
```

## UI Components

`@acg/ecp-auth` 只负责 runtime（会话、路由守卫、权限判断），不包含登录页/无权限页/workspace 等 UI。
如需这些组件，请使用 `@acg/ecp-auth-vue`：

- 包说明：`ecp-sdk-frontend/packages/ecp-auth-vue/README.md`
- workspace Web Component 懒加载：`@acg/ecp-auth-vue/workspace/loader`
- Vue 组件入口：`@acg/ecp-auth-vue/login/vue`、`@acg/ecp-auth-vue/no-permission/vue`、`@acg/ecp-auth-vue/workspace/vue`

建议后端仅返回当前 `tenant_id` 可见的账号摘要字段（如 `id/name/email/phone/avatar/departmentName`），避免跨租户数据泄露。

## Backend Contract Notes

当前 SDK 默认依赖以下前端可调用接口（需配合后端提供）：

- `GET /api/v1/public/session`
- `GET /api/v1/public/permissions`
- `POST /api/v1/public/session/permissions/check`

`GET /api/v1/public/session` 建议至少返回：

- `roles[]`
- `permissionCodes[]`
- `features[]`（`{ code, name }`，用于功能级判断与页面展示）

`GET /api/v1/public/permissions` 建议返回当前会话权限快照：

- `permissionCodes[]`
- `roleCodes[]`
- `featureCodes[]`

如果暂未开放这些接口，可通过 `transport` 和 `endpoints` 自定义适配。

## Package Name

- 认证核心 runtime：`@acg/ecp-auth`
- Vue 组件聚合包：`@acg/ecp-auth-vue`

## Package Build

```bash
cd ecp-sdk-frontend/packages/ecp-auth
npm install
npm run build
```

`@acg/ecp-auth` 仅构建认证与权限 runtime（不包含 UI 资产）。
Workspace web component 与样式资产由 `@acg/ecp-auth-vue` 负责。
