# ECP Core SDK

`@acg/ecp-core` 提供 ECP 前端 SDK 的基础运行时能力：

- storage adapter（localStorage/memory）
- request/error/header 工具

构建：

```bash
npm run build
```

