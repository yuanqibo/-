# ECP SDK

`@acg/ecp-sdk` 是 ECP 前端平台总门面。

当前首个正式挂载模块为 `AUTH`，用于承载：

- account
- permission
- menu
- workspace

未来可以继续挂载：

- notify
- workflow

## Quick Start

```bash
npm install @acg/ecp-sdk @acg/ecp-auth-vue
```

```ts
import { createEcpSdk } from '@acg/ecp-sdk'

const ecp = createEcpSdk({
  appCode: 'PL9V8N',
  modules: { auth: true }
})

await ecp.setup({
  router,
  locale: 'zh-CN'
})
```

```ts
import { createApp } from 'vue'
import { createEcpUiPlugin } from '@acg/ecp-ui'
import App from './App.vue'

createApp(App)
  .use(createEcpUiPlugin())
  .mount('#app')
```

`@acg/ecp-sdk` 只负责平台总门面。启用 `AUTH` 模块时，请显式安装 `@acg/ecp-auth-vue`。
如果配置了 `auth` 或启用了 `AUTH`，但运行时缺少 `@acg/ecp-auth-vue`，SDK 会输出明确警告并阻止继续初始化。`@acg/ecp-sdk` 会通过 `@acg/ecp-auth-vue/facade` 加载 AUTH 运行时，避免根入口引入非必需视图副作用。
未显式传入 `baseUrl` 时，AUTH 模块默认使用同域 `/api/v1`。

建议统一安装 `@acg/ecp-ui` 插件或等价 token 注入，以保证登录页、无权限页和业务主站使用一致设计令牌。

如果本地 bundle 的菜单项同时声明了 `pageKey + file`，推荐直接在 `authz/bundle.ts` 里把 YAML 和 Vue 文件一起交给 `createBundleFromGlob(...)`，这样 `createEcpSdk(...)` 不需要再重复配置 `pageFiles`：

```ts
import { createBundleFromGlob } from '@acg/ecp-auth-vue'

const authzFiles = {
  ...import.meta.glob('./authz/*.yaml', { eager: true, import: 'default' }),
  ...import.meta.glob('/src/views/**/*.vue')
}

const authzBundle = createBundleFromGlob(authzFiles)

const ecp = createEcpSdk({
  appCode: 'PL9V8N',
  modules: { auth: true },
  auth: {
    bundle: authzBundle
  }
})
```

这里的 `file` 只用于当前前端工程的自动 import，不会替代 `pageKey` 作为平台稳定标识。`auth.pageFiles` 仍然保留为高级兜底配置，但不再是推荐主路径。
